﻿using WebProject.Data;
using WebProject.Models;

namespace WebProject.Repositories
{
    public class MyRepo : IRepo
    {
        private AnimalContext _context;
        public MyRepo(AnimalContext context)
        {
            _context = context;
        }
        public void AddAnimal(Animal animal)
        {
            _context.Animals!.Add(animal);
            _context.SaveChanges();
        }

        public void AddCategory(Category category)
        {
            _context.Catagories!.Add(category);
            _context.SaveChanges();
        }

        public void AddComment(Comment comment)
        {
            _context.Comments!.Add(comment);
            _context.SaveChanges();
        }

        public Animal GetAnimalById(int id)
        {
            return _context.Animals!.Where(a => a.AnimalId == id).FirstOrDefault()!;
        }

        public IEnumerable<Animal> GetAnimals()
        {
            return _context.Animals!;
        }

        public IEnumerable<Animal> GetAnimalsByCategory(int id)
        {
            return _context.Animals!.Where(a => a.CategoryId == id);
        }

        public IEnumerable<Category> GetCategories()
        {
            return _context.Catagories!;
        }

        public IEnumerable<Comment> GetComments()
        {
            return _context.Comments!;
        }

        public IEnumerable<Comment> GetCommentsByAnimalId(int id)
        {
            return _context.Comments!.Where(c => c.AnimalId == id);
        }

        public void RemoveAnimal(int id)
        {
            var animal = _context.Animals!.Single(m => m.AnimalId == id);
            _context.Animals!.Remove(animal);
            _context.SaveChanges();
        }

        public void RemoveCategory(int id)
        {
            var category = _context.Catagories!.Single(m => m.CategoryId == id);
            _context.Catagories!.Remove(category);
            _context.SaveChanges();
        }

        public void RemoveComment(int id)
        {
            var comment = _context.Comments!.Single(m => m.CommentId == id);
            _context.Comments!.Remove(comment);
            _context.SaveChanges();
        }

        public IEnumerable<Animal> Top2Commented()
        {
            return _context.Animals!.OrderByDescending(a => a.Comments!.Count).Take(2);
        }

        public void UpdateAnimal(int id, Animal animal)
        {
            var animalInDb = _context.Animals!.Single(m => m.AnimalId == id);
            animalInDb.Name = animal.Name;
            animalInDb.Age = animal.Age;
            animalInDb.Image = animal.Image;
            animalInDb.Info = animal.Info;
            animalInDb.Description = animal.Description;
            animalInDb.CategoryId = animal.CategoryId;
            _context.SaveChanges();
        }
    }
}
