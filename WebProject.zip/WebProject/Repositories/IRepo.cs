﻿using WebProject.Models;

namespace WebProject.Repositories
{
    /// <summary>
    /// the repository that allows interaction with the database
    /// </summary>
    public interface IRepo
    {
        /// <summary>
        /// returns a collection of animals from the database
        /// </summary>
        /// <returns></returns>
        IEnumerable<Animal> GetAnimals();
        /// <summary>
        /// returns a collection of categories from the database
        /// </summary>
        /// <returns></returns>
        IEnumerable<Category> GetCategories();
        /// <summary>
        /// returns a collection of comments from the database
        /// </summary>
        /// <returns></returns>
        IEnumerable<Comment> GetComments();
        /// <summary>
        /// adds an animal to the database by passed animal
        /// </summary>
        /// <param name="animal"></param>
        void AddAnimal(Animal animal);
        /// <summary>
        /// removes an animal from the database by id
        /// </summary>
        /// <param name="id"></param>
        void RemoveAnimal(int id);
        /// <summary>
        /// adds a category to the database by passed category
        /// </summary>
        /// <param name="category"></param>
        void AddCategory(Category category);
        /// <summary>
        /// removes a category from the database by id 
        /// </summary>
        /// <param name="id"></param>
        void RemoveCategory(int id);
        /// <summary>
        /// adds a comment to the database by passed comment
        /// </summary>
        /// <param name="comment"></param>
        void AddComment(Comment comment);
        /// <summary>
        /// removes a comment from the database by id
        /// </summary>
        /// <param name="id"></param>
        void RemoveComment(int id);
        /// <summary>
        /// updates a selected animal by id with a passed animal
        /// </summary>
        /// <param name="id"></param>
        /// <param name="animal"></param>
        void UpdateAnimal(int id, Animal animal);
        /// <summary>
        /// returns a specific animal by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Animal GetAnimalById(int id);
        /// <summary>
        /// returns a collection of top 2 animal by most comments
        /// </summary>
        /// <returns></returns>
        IEnumerable<Animal> Top2Commented();
        /// <summary>
        /// returns a collection of comments by the animal's id 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        IEnumerable<Comment> GetCommentsByAnimalId(int id);
        /// <summary>
        /// returns a collection of animals by the category's id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        IEnumerable<Animal> GetAnimalsByCategory(int id);
    }
}
