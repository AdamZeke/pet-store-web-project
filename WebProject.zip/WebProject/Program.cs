using Microsoft.EntityFrameworkCore;
using WebProject.Data;
using WebProject.Repositories;

var builder = WebApplication.CreateBuilder(args);
string connectionString = builder.Configuration["ConnectionStrings:DefaultConnection"]; //receives the sql server connection string from the json file
builder.Services.AddTransient<IRepo, MyRepo>(); //injects my service to the app
builder.Services.AddDbContext<AnimalContext>(options => options.UseSqlServer(connectionString)); // connects the app to a SQL db
builder.Services.AddControllersWithViews(); // allows the app to work in the MVC format
var app = builder.Build();



if (!app.Environment.IsDevelopment()) //If the app is in the development stage, if an exception is thrown it will show it 
                                     // instead of redirecting to the error controller and the index action
{
    app.UseExceptionHandler("/Error/Index"); //change to production in launchSetting before showing the project
}

app.Use(async (context, next) => //rerouting the user if the url request path is unknown
{
    await next();
    if (context.Response.StatusCode == 404)
    {
        context.Request.Path = "/Error/Index";
        await next();
    }
});

using (var scope = app.Services.CreateScope())
{
    var ctx = scope.ServiceProvider.GetRequiredService<AnimalContext>();
    ctx.Database.EnsureDeleted(); //Remove this line in order to keep the database updated when the app closes
    ctx.Database.EnsureCreated();
}

app.UseRouting(); // allows using routing to endpoints

app.UseStaticFiles(); //allows using static files in the wwwroot folder 

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute("Default", "{controller=Store}/{action=Home}"); //default endpoint for when the app starts
});

app.Run();
