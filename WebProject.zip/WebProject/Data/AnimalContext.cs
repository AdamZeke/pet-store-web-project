﻿using Microsoft.EntityFrameworkCore;
using WebProject.Models;

namespace WebProject.Data
{
    /// <summary>
    /// the db context class that interacts with the database
    /// </summary>
    public class AnimalContext : DbContext
    {
        public AnimalContext(DbContextOptions<AnimalContext> options) : base(options) { }
        /// <summary>
        /// the animals db set
        /// </summary>
        public DbSet<Animal>? Animals { get; set; }
        /// <summary>
        /// the categories db set
        /// </summary>
        public DbSet<Category>? Catagories { get; set; }
        /// <summary>
        /// the comments db set
        /// </summary>
        public DbSet<Comment>? Comments { get; set; }

        /// <summary>
        /// initializes the database and injects data into it when the application starts
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Category>().HasData(
                new { CategoryId = 1, CategoryName = "Canines" },
                new { CategoryId = 2, CategoryName = "Birds" },
                new { CategoryId = 3, CategoryName = "Reptiles" },
                new { CategoryId = 4, CategoryName = "Fish" },
                new { CategoryId = 5, CategoryName = "Mammals" }
                );

            modelBuilder.Entity<Animal>().HasData(
                new { AnimalId = 1, Name = "Labrador", Age = 3, Image = @"Images\Dog1.jpeg", Description = "The sweet-faced, lovable Labrador Retriever is America's most popular dog breed. Labs are friendly, outgoing, and high-spirited companions who have more than enough affection to go around for a family looking for a medium-to-large dog. The sturdy, well-balanced Labrador Retriever can, depending on the sex, stand from 21.5 to 24.5 inches at the shoulder and weigh between 55 to 80 pounds. The dense, hard coat comes in yellow, black, and a luscious chocolate. The head is wide, the eyes glimmer with kindliness, and the thick, tapering 'otter tail' seems to be forever signaling the breed's innate eagerness. Labs are famously friendly. They are companionable housemates who bond with the whole family, and they socialize well with neighbor dogs and humans alike. But don't mistake his easygoing personality for low energy: The Lab is an enthusiastic athlete that requires lots of exercise, like swimming and marathon games of fetch, to keep physically and mentally fit.", Info = "An amazing dog which is super friendly and cute!", CategoryId = 1 },
                new { AnimalId = 2, Name = "Wolf", Age = 5, Image = @"Images\wolf1.jpeg", Description = "The wolf, also known as the gray wolf or grey wolf, is a large canine native to Eurasia and North America. More than thirty subspecies of Canis lupus have been recognized, and gray wolves, as popularly understood, comprise wild subspecies. The wolf is the largest extant member of the family Canidae. It is also distinguished from other Canis species by its less pointed ears and muzzle, as well as a shorter torso and a longer tail. The wolf is nonetheless related closely enough to smaller Canis species, such as the coyote and the golden jackal, to produce fertile hybrids with them. The banded fur of a wolf is usually mottled white, brown, gray, and black, although subspecies in the arctic region may be nearly all white.", Info = "An animal not to be raised by a fainted heart. It's aggressive and difficult to handle.", CategoryId = 1 },
                new { AnimalId = 3, Name = "Bald eagle", Age = 1, Image = @"Images\eagle1.jpeg", Description = "The bald eagle is a bird of prey found in North America. A sea eagle, it has two known subspecies and forms a species pair with the white-tailed eagle (Haliaeetus albicilla), which occupies the same niche as the bald eagle in the Palearctic. Its range includes most of Canada and Alaska, all of the contiguous United States, and northern Mexico. It is found near large bodies of open water with an abundant food supply and old-growth trees for nesting.", Info = "A majestic bird of prey which represents the American nation. Requires experience in order to handle.", CategoryId = 2 },
                new { AnimalId = 4, Name = "Flamingo", Age = 2, Image = @"Images\falmingo1.jpeg", Description = "Flamingos are a type of wading bird in the family Phoenicopteridae, which is the only extant family in the order Phoenicopteriformes. There are four flamingo species distributed throughout the Americas (including the Caribbean), and two species native to Afro-Eurasia.", Info = "The flamingo is a large pink bird, used mainly for decoration.. The bird doesn't require much maintenance", CategoryId = 2 },
                new { AnimalId = 5, Name = "King Cobra", Age = 2, Image = @"Images\king-cobra1.jpeg", Description = "The King Cobra s a species of venomous elapid snake endemic to jungles in Southern and Southeast Asia. The sole member of the genus Ophiophagus, it is distinguishable from other cobras, most noticeably by its size and neck patterns. The king cobra is the world's longest venomous snake, with an average length of 3.18 to 4 m (10.4 to 13.1 ft),[2] reaching a maximum of 5.85 m (19.2 ft).[3] Its skin colour varies across the habitats, from black with white stripes to unbroken brownish grey. It preys chiefly on other snakes, including its own species. Unlike other snakes, it rarely hunts other vertebrates, such as rodents and lizards.", Info = "The King Cobra is a dangerous snake that should not be taken lightly, and should not be raised by ordinary people.", CategoryId = 3 },
                new { AnimalId = 6, Name = "Chameleon", Age = 3, Image = @"Images\chameleon1.jpeg", Description = "Chameleons are a distinctive and highly specialized clade of Old World lizards with 202 species described as of June 2015.[1] The members of this family are best known for their distinct range of colors, being capable of shifting to different hues and degrees of brightness. The large number of species in the family exhibit considerable variability in their capacity to change color. For some, it is more of a shift of brightness (shades of brown); for others, a plethora of color-combinations (reds, yellows, greens, blues) can be seen.", Info = "Cameleons are beautiful little lizards that can be raised at home, they change their color often and can be used as a decoration piece.", CategoryId = 3 },
                new { AnimalId = 7, Name = "Goldfish", Age = 1, Image = @"Images\goldfish1.jpeg", Description = "The Goldfish is a freshwater fish in the family Cyprinidae of order Cypriniformes. It is commonly kept as a pet in indoor aquariums, and is one of the most popular aquarium fish. Goldfish released into the wild have become an invasive pest in parts of North America.[", Info = "The Goldfish is a fish that's common and easy to raise! A perfect gift for a child that wants a new pet.", CategoryId = 4 },
                new { AnimalId = 8, Name = "Largetooth sawfish", Age = 4, Image = @"Images\largetooth-sawfish1.jpeg", Description = "The Largetooth sawfish is a species of sawfish, family Pristidae. It is found worldwide in tropical and subtropical coastal regions, but also enters freshwater. It has declined drastically and is now critically endangered.", Info = "A rare fish that needs special care. The people who choose to raise them should be of great knowledge about it's kind and it's needs.", CategoryId = 4 },
                new { AnimalId = 9, Name = "Cat", Age = 3, Image = @"Images\cat1.jpeg", Description = "The cat is a domestic species of small carnivorous mammal. It is the only domesticated species in the family Felidae and is commonly referred to as the domestic cat or house cat to distinguish it from the wild members of the family.[4] Cats are commonly kept as house pets, but can also be farm cats or feral cats; the feral cat ranges freely and avoids human contact.[5] Domestic cats are valued by humans for companionship and their ability to kill rodents. About 60 cat breeds are recognized by various cat registries.", Info = "A great pet to raise at any home! The cat is a companion for life which doesn't require a lot of maintenance.", CategoryId = 5 },
                new { AnimalId = 10, Name = "Grizzly Bear", Age = 15, Image = @"Images\grizzly-bear1.jpeg", Description = "The Grizzly bear is a common name for one of the brown bears (Ursus arctos) belonging to the subspecies U. arctos horribilis. The grizzly bear is a massive animal with humped shoulders and an elevated forehead that contributes to a somewhat concave profile. The fur is brownish to buff, and the hairs are usually silver- or pale-tipped, giving the grizzled effect for which the bear is named. The term grizzly bear, however, is often applied informally to brown bears of North America regardless of subspecies.", Info = "A big bear which requires super specific care in order to raise. People who wish to purchase this bear must pass a regulated exam beforehand.", CategoryId = 5 }
                );

            Comment c1 = new() { CommentId = 1, CommentText = "WOW! He's so cute!!", AnimalId = 1 };
            Comment c2 = new() { CommentId = 2, CommentText = "Oh my god, an amazing creature! God bless America.", AnimalId = 3 };
            Comment c3 = new() { CommentId = 3, CommentText = "Ew! Can't imagine why anyone would get this..", AnimalId = 5 };
            Comment c4 = new() { CommentId = 4, CommentText = "I love fish, too bad they keep dying on me.", AnimalId = 7 };
            Comment c5 = new() { CommentId = 5, CommentText = "OMG so cute!!!", AnimalId = 9 };
            Comment c6 = new() { CommentId = 6, CommentText = "I love dogs. He's adorable!", AnimalId = 1 };
            Comment c7 = new() { CommentId = 7, CommentText = "SO CUTE!!!", AnimalId = 1 };
            Comment c8 = new() { CommentId = 8, CommentText = "wow, i love these awesome birds.", AnimalId = 3 };

            modelBuilder.Entity<Comment>().HasData(c1, c2, c3, c4, c5, c6, c7, c8);
        }
    }
}
