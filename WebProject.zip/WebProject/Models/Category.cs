﻿namespace WebProject.Models
{
    /// <summary>
    /// the category class
    /// </summary>
    public class Category
    {
        /// <summary>
        /// the category's id
        /// </summary>
        public int CategoryId { get; set; }
        /// <summary>
        /// the category's name
        /// </summary>
        public string? CategoryName { get; set; }
    }
}
