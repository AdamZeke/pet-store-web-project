﻿using System.ComponentModel.DataAnnotations;

namespace WebProject.Models
{
    /// <summary>
    /// the comment class
    /// </summary>
    public class Comment
    {
        /// <summary>
        /// the comment's id
        /// </summary>
        [Key]
        public int? CommentId { get; set; }
        /// <summary>
        /// the comment's text, has to be up to 60 characters
        /// </summary>
        [Required(ErrorMessage = "Don't leave the comment empty!")]
        [StringLength(60)]
        public string? CommentText { get; set; }
        /// <summary>
        /// the animal that the comment refers to 
        /// </summary>
        public int AnimalId { get; set; }
    }
}
