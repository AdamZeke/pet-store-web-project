﻿using System.ComponentModel.DataAnnotations;

namespace WebProject.Models
{
    /// <summary>
    /// the Animal class
    /// </summary>
    public class Animal
    {
        /// <summary>
        /// Animal's ID
        /// </summary>
        [Required(ErrorMessage = "Please enter an id")]
        [Display(Name = "ID:")]
        public int AnimalId { get; set; }
        /// <summary>
        /// Animal's name, required
        /// </summary>
        [Required(ErrorMessage = "Please enter a name")]
        [Display(Name = "Name:")]
        public string? Name { get; set; }
        /// <summary>
        /// Animal's age in years, required between 0-150
        /// </summary>
        [Required(ErrorMessage = "Please enter an age"), Range(0, 150)]
        [Display(Name = "Age:")]
        public int Age { get; set; }
        /// <summary>
        /// Animal's image, required
        /// </summary>
        [Required(ErrorMessage = "Please enter an image")]
        [Display(Name = "Image:")]
        public string? Image { get; set; }
        /// <summary>
        /// Animal's description, required
        /// </summary>
        [Required(ErrorMessage = "Please enter a description")]
        [Display(Name = "Description:")]
        public string? Description { get; set; }
        /// <summary>
        /// Animal's short info, required
        /// </summary>
        [Required(ErrorMessage = "Please enter a little bit of information")]
        [Display(Name = "Info:")]
        public string? Info { get; set; }
        /// <summary>
        /// Animal's category, required
        /// </summary>
        [Required(ErrorMessage = "Please associate to a category!")]
        [Display(Name = "Category ID:")]
        public int CategoryId { get; set; }
        /// <summary>
        /// the collection of comments on the animal
        /// </summary>
        public virtual ICollection<Comment>? Comments { get; set; }
    }
}
