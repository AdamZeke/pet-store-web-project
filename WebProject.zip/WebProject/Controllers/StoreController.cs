﻿using Microsoft.AspNetCore.Mvc;
using WebProject.Models;
using WebProject.Repositories;

namespace WebProject.Controllers
{
    /// <summary>
    /// the controller that manages all of the store related actions
    /// </summary>
    public class StoreController : Controller
    {
        private IRepo _repo; // my repository that conatins the functions in order to access and use the database
        /// <summary>
        /// the constructor that initializes the injected services
        /// </summary>
        /// <param name="repo"></param>
        public StoreController(IRepo repo)
        {
            _repo = repo;
        }
        /// <summary>
        /// returns the main cshtml page that shows the 2 most commented on animals
        /// </summary>
        /// <returns></returns>
        public IActionResult Home()
        {
            return View(_repo.Top2Commented());
        }
        /// <summary>
        /// returns the catelog cshtml page which shows all of the animals in the store
        /// </summary>
        /// <returns></returns>
        public IActionResult Catelog()
        {
            return View(_repo.GetAnimals());
        }
        /// <summary>
        /// returns the cshtml page that shows the details of the chosen animal 
        /// and gets all of the comments on the chosen animal, this is the page where you can comment on the animal
        /// </summary>
        /// <param name="animal"></param>
        /// <returns></returns>
        public IActionResult Details(Animal animal)
        {
            if (animal.Name != null)
            {
                switch (animal.CategoryId)
                {
                    case 1:
                        ViewBag.Category = "Canines";
                        break;
                    case 2:
                        ViewBag.Category = "Birds";
                        break;
                    case 3:
                        ViewBag.Category = "Reptiles";
                        break;
                    case 4:
                        ViewBag.Category = "Fish";
                        break;
                    case 5:
                        ViewBag.Category = "Mammals";
                        break;
                }

                ViewBag.Animal = animal;
                return View(_repo.GetCommentsByAnimalId(animal.AnimalId));
            }
            return RedirectToAction("Home");
        }
        /// <summary>
        /// returns the main admin page and shows all of the animals in the store
        /// </summary>
        /// <returns></returns>
        public IActionResult Admin()
        {
            return View(_repo.GetAnimals());
        }
        /// <summary>
        /// adds a comment to the database and then redirects back to the animal's details page,
        /// if the comment is invalid a redirection to the home page will happen
        /// </summary>
        /// <param name="c"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Comment(string c, int id)
        {
            var animal = _repo.GetAnimalById(id);
            if (c != null && c.Length <= 60 && animal != null)
            {
                Comment nc = new() { AnimalId = id, CommentText = c };
                _repo.AddComment(nc);
                return RedirectToAction("Details", animal);
            }
            return RedirectToAction("Home");
        }
        /// <summary>
        /// returns a cshtml page with the animals by the selected category
        /// </summary>
        /// <param name="catid"></param>
        /// <returns></returns>
        public IActionResult Category(int catid)
        {
            switch (catid)
            {
                case 1:
                    ViewBag.Category = "Canines";
                    break;
                case 2:
                    ViewBag.Category = "Birds";
                    break;
                case 3:
                    ViewBag.Category = "Reptiles";
                    break;
                case 4:
                    ViewBag.Category = "Fish";
                    break;
                case 5:
                    ViewBag.Category = "Mammals";
                    break;
            }
            return View(_repo.GetAnimalsByCategory(catid));
        }
    }
}
