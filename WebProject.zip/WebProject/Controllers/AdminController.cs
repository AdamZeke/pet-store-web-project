﻿using Microsoft.AspNetCore.Mvc;
using WebProject.Models;
using WebProject.Repositories;

namespace WebProject.Controllers
{
    /// <summary>
    /// the controller for all of the admin related actions
    /// </summary>
    public class AdminController : Controller
    {
        private IRepo _repo; // my repository that contains the actions to interact with the database
        private IWebHostEnvironment _webHost; // a repository that allows the images to be saved in the wwwroot folder
        /// <summary>
        /// The constructor for the Admin controller which initializes the injected services
        /// </summary>
        /// <param name="repo"></param>
        /// <param name="webHostEnviorment"></param>
        public AdminController(IRepo repo, IWebHostEnvironment webHostEnviorment)
        {
            _repo = repo;
            _webHost = webHostEnviorment;
        }
        /// <summary>
        /// returns the cshtml page in order to add an animal
        /// </summary>
        /// <returns></returns>
        public IActionResult AddAnimal()
        {
            return View();
        }
        /// <summary>
        /// removes the animal with the selected id and returns the main admin page
        /// </summary>
        /// <param name="AnimalId"></param>
        /// <returns></returns>
        public IActionResult RemoveAnimal(int AnimalId)
        {
            _repo.RemoveAnimal(AnimalId);
            return RedirectToAction("Admin", "Store");
        }
        /// <summary>
        /// returns the animal edit cshtml page with the values of the selected animal
        /// </summary>
        /// <param name="animal"></param>
        /// <returns></returns>
        public IActionResult EditAnimal(Animal animal)
        {
            ViewBag.Animal = animal;
            return View();
        }
        /// <summary>
        /// returns the cshtml page with the animals of the selected category
        /// </summary>
        /// <param name="catId"></param>
        /// <returns></returns>
        public IActionResult AdminCategories(int catId)
        {
            switch (catId)
            {
                case 1:
                    ViewBag.Category = "Canines";
                    break;
                case 2:
                    ViewBag.Category = "Birds";
                    break;
                case 3:
                    ViewBag.Category = "Reptiles";
                    break;
                case 4:
                    ViewBag.Category = "Fish";
                    break;
                case 5:
                    ViewBag.Category = "Mammals";
                    break;
            }
            return View(_repo.GetAnimalsByCategory(catId));
        }
        /// <summary>
        /// adds an animal with the entered parameters to the database and then returns the main admin page
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="Age"></param>
        /// <param name="Image"></param>
        /// <param name="Description"></param>
        /// <param name="CategoryId"></param>
        /// <param name="Info"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Add(string Name, int Age, IFormFile Image, string Description, int CategoryId, string Info)
        {
            if (ModelState.IsValid)
            {
                var SaveImage = Path.Combine(_webHost.WebRootPath, "Images", Image.FileName);
                string Type = Path.GetExtension(Image.FileName);

                if (Type == ".jpeg" || Type == ".jpg" || Type == ".png")
                {
                    using (var upload = new FileStream(SaveImage, FileMode.Create))
                    {
                        await Image.CopyToAsync(upload);
                    }
                    Animal a = new() { Name = Name, Age = Age, Image = @"Images\" + Image.FileName, Description = Description, Info = Info, CategoryId = CategoryId };
                    _repo.AddAnimal(a);
                }
            }
            return RedirectToAction("Admin", "Store");
        }
        /// <summary>
        /// creates a new animal and assigns it's values to the selected animal
        /// in order to edit it's details and then returns the main admin page
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="Age"></param>
        /// <param name="Image"></param>
        /// <param name="Description"></param>
        /// <param name="CategoryId"></param>
        /// <param name="Info"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Edit(string Name, int Age, IFormFile Image, string Description, int CategoryId, string Info, int id)
        {
            if (ModelState.IsValid)
            {
                var SaveImage = Path.Combine(_webHost.WebRootPath, "Images", Image.FileName);
                string Type = Path.GetExtension(Image.FileName);
                if (Type == ".jpeg" || Type == ".jpg" || Type == ".png")
                {
                    using (var upload = new FileStream(SaveImage, FileMode.Create))
                    {
                        await Image.CopyToAsync(upload);
                    }
                    Animal a = new() { Name = Name, Age = Age, Image = @"Images\" + Image.FileName, Description = Description, Info = Info, CategoryId = CategoryId };
                    _repo.UpdateAnimal(id, a);
                }
            }
            return RedirectToAction("Admin", "Store");
        }
    }
}
