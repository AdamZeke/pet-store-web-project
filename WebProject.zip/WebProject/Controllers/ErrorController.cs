﻿using Microsoft.AspNetCore.Mvc;

namespace WebProject.Controllers
{
    /// <summary>
    /// the controller for managing the exceptions
    /// </summary>
    public class ErrorController : Controller
    {
        /// <summary>
        /// returns a cshtml page in order to redirect the user 
        /// if an exception is thrown
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View();
        }
    }
}
